package com.project_VDNRV.securedmessaging;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;


public class RecycleViewHolder extends   RecyclerView.Adapter<RecycleViewHolder.MyViewHolder> {

        private List<User> userList;

        public class MyViewHolder extends RecyclerView.ViewHolder {
            public TextView name,message;

            public MyViewHolder(View view) {
                super(view);
                name = (TextView) view.findViewById(R.id.user_name);
                message = (TextView) view.findViewById(R.id.mess);
            }
        }


        public RecycleViewHolder(List<User> userList) {
            this.userList = userList;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.user_row_item, parent, false);

            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            User user = userList.get(position);
            holder.name.setText(user.getName());
            holder.message.setText(user.getMessage());
        }

        @Override
        public int getItemCount() {
            return userList.size();
        }
    }



