package com.project_VDNRV.securedmessaging;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.project_VDNRV.securedmessaging.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText mail,pswd;
        Button log_button,reg;
        final Intent intent = new Intent(this, User_List.class);

        mail = findViewById(R.id.email);
        pswd= findViewById(R.id.password);
        reg = findViewById(R.id.register);
        log_button = findViewById(R.id.login);


       log_button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               String mail_id,pass;
               mail_id= mail.getText().toString().trim();
               pass = pswd.getText().toString().trim();
               if(mail_id.isEmpty()) {
                   mail.setError("e-mail cannot bo empty");
                   mail.requestFocus();
               }
               else
               if(pass.isEmpty())
               {
                   pswd.setError("Password cannot be empty");
                   pswd.requestFocus();
               }
               else {

                   FirebaseAuth mAuth;
                   mAuth = FirebaseAuth.getInstance();
                   mAuth.signInWithEmailAndPassword(mail_id, pass).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                               @Override
                               public void onComplete(@NonNull Task<AuthResult> task) {
                                   if (task.isSuccessful()) {
                                       Toast.makeText(MainActivity.this, "Authentication Succeed.", Toast.LENGTH_SHORT).show();

                                       startActivity(intent);

                                   } else {
                                       Toast.makeText(MainActivity.this, "Authentication failed. check Login Credentials", Toast.LENGTH_LONG).show();

                                   }

                               }
                           });
               }
           }
       });
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String mail_id,pass;
                mail_id= mail.getText().toString().trim();
                pass = pswd.getText().toString().trim();
                if(mail_id.isEmpty()) {
                    mail.setError("e-mail cannot to empty");
                    mail.requestFocus();
                }
                else
                    if(pass.isEmpty())
                    {
                        pswd.setError("Password cannot be empty");
                        pswd.requestFocus();
                    }
                    else {

                        FirebaseAuth mAuth;
                        mAuth = FirebaseAuth.getInstance();
                        mAuth.createUserWithEmailAndPassword(mail_id, pass)
                                .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(MainActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                                            startActivity(intent);

                                        } else {

                                            Toast.makeText(MainActivity.this, "Registration Failed,", Toast.LENGTH_SHORT).show();
                                        }

                                    }
                                });

                    }





            }
        });



    }
}
