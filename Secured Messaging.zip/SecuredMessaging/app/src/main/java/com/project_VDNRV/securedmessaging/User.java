package com.project_VDNRV.securedmessaging;

public class User {
    private String name, message;
    public User()
    {
        this.name=null;
        this.message=null;

    }

    public User(String nm,String msg)
    {
        this.name = nm;
        this.message= msg;
    }

    public  String getName()
    {
        return this.name;
    }
    public void setName(String nm)
    {
        this.name = nm;
    }
    public String getMessage()
    {
        return this.message;
    }
    public void setMessage(String msg)
    {
        this.message=msg;
    }
}
